import Glide from "@glidejs/glide";

new Glide('.glide', {
    type: "carousel",
    autoplay: 1000
}).mount();