import "%blocks%/header/header.js";
import "%blocks%/footer/footer.js";
import "%blocks%/main/main.js";